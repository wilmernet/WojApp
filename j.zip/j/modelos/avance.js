const { Schema, model } = require('mongoose')

const avance = new Schema({

  identificador: {
    type: String,
    required: true,
    unique: true
  },
  identificador_proyecto: {
    type: Schema.Types.ObjectId,
    ref: ProjectModel,
    required: true,
    unique: true
  },
  fecha_avance: {
    type: Date,
    required: true,
  },
  descripcion_avance: {
    type: String,
    required: true,
  },
  observaciones_avance: {
    type: String,
    required: true,
  },
  avance_creado_por: {
    type: Schema.Types.ObjectId,
    ref: UserModel,
    required: true,
  },
});

module.exports = model('avances', avance)