const {inscription} = require ('./inscripciones')
const {avance } = require('./avance')

const resolvers = [inscription , avance]

module.exports = {resolvers}
