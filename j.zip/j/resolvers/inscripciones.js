const inscription = require ('../modelos/inscripciones')

const inscripcionesResolvers = {
    Query: {
        inscripciones: async (parent, args) => {
            const inscripciones = await inscription.find();
            return inscripciones;
        }
    },
    Mutation:{
        crearInscripcion: async (parent, args) => {
            const inscripcionCreada = await inscription.create({
                estado_inscripcion: args.estado,
                identificador_proyecto: args.proyecto,
                identificador_estudiante: args.estudiante,
            });
            return inscripcionCreada;
        },
        aprobarInscripcion: async (parent, args) => {
            const inscripcionAprobada = await inscription.findByIdAndUpdate(args.id, {
                estado_inscripcion: 'Aceptada',
                fecha_ingreso: Date.now(),
            });
            return inscripcionAprobada;
        }, 
    }
}

modelo.exports = {inscripcionesResolvers}