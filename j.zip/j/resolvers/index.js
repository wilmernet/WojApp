const {avance} = require ('./avance')
const {inscripciones} = require ('./inscripciones')

const resolvers = [avance,inscripciones]
moduel.exports = {resolvers}