const avance = require('../modelos/avance')

const avanceResolvers = {
    Query: {
        avances: async (parent, args) => {
            const avances = await avance.find().populate('identificador_proyecto').populate('avance_creado_por');
            return avances;
         },
         filtrarAvance: async (parents, args) => {
            const avanceFiltrado = await avance.find({ identificador_proyecto: args.idProyecto })
              .populate('identificador_proyecto')
              .populate('avance_creado_por');
            return avanceFiltrado;
        }
    },
    Mutation:{
        crearAvance: async (parents, args) => {
            const avanceCreado = await avance.create({
                fecha_avance: args.fecha,
                descripcion_avance: args.descripcion_avance,
                observaciones_avance: args.observaciones_avance,
                identificador_proyecto: args.identificador_proyecto,
                avance_creado_por: args.avance_creado_por,
            });
            return avanceCreado;
          },
    }
}

module.exports = {avanceResolvers}



































