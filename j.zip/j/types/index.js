const {avanceType} = require ('./avance.js')
const {inscripciones} = require ('./inscripciones.js')

const types = [avanceType ,inscripciones]
module.exports = {types}