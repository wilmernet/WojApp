const {gql} = require ("apollo-server-express");

const incriptionType = gql`
    type Inscripcion {
        identificador: ID!
        identificador_proyecto: Proyecto
        identificador_estudiante: Usuario
        estado_inscripcion: Enum_EstadoInscripcion
        fecha_ingreso: Date
        fecha_egreso: Date
    }

    type Query{
        Inscripciones: [Inscripcion]
    }
    type Mutation{
        crearInscripcion(estado_inscripcion:Enum_EstadoInscripcion, identificador_proyecto:String, identificador_estudiante:String):Inscripcion
        aprobarInscripcion(id:String):Inscripcion
    }
`;
module.exports = {incriptionType}