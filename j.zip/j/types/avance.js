const {gql} = require ("apollo-server-express");

const avanceType = gql`
    type Avance {
        identificador: ID
        identificador_proyecto: identificador_proyecto
        fecha_avance: Date
        descripcion_avance: String
        observaciones_avance: [String]
        avance_creado_por: Usuario
    }
    type Query{
        Avances: [Avance]
        filtrarAvance(idProyecto: String!): [Avance] 
    }
    type Mutation{
        crearAvance(fecha_avance:Date, descripcion_avance:String, observaciones_avance:String, identificador_proyecto:String, avance_creado_por:String): Avance
    }

`;

module.exports = {avanceType}