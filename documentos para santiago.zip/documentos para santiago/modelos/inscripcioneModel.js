const { Schema, model } = require('mongoose')

const inscription = new Schema({
    identificador: {
      type: String,
      required: true,
      unique: true
    },
    identificador_proyecto: {
      type: Schema.Types.ObjectId,
      ref: ProjectModel,
      required: true,
      unique: true
    },
    identificador_estudiante: {
      type: Schema.Types.ObjectId,
      ref: UserModel,
      required: true,
      unique: true
    },
    estado_inscripcion: {
      type: String,
      enum: ['Aceptada', 'Rechazada', 'Pendiente'],
      default: 'Pendiente',
      required: true
    },
    fecha_ingreso: {
      type: Date,
      required: false
    },
    fecha_egreso: {
      type: Date,
      required: false
    },
},
    {
        timestamps: true
    }
)
module.exports = model('inscripciones', inscription)