const { gql } = require('apollo-server-express')

//Nodemon
const typeDefs = gql`
    scalar Date
    type Usuario{
        nombre: String
        identificacion: Int
        estado: String
        email: String
        perfil: String
    }
    type Proyecto{
        identificador: String
        objetivosGenerales: String
        presupuesto: Int
        fechaTerminacion: Date
        lider: String
        nombre:String
    }
    type Inscripcion {
        identificador: ID!
        identificador_proyecto: Proyecto
        identificador_estudiante: Usuario
        estado_inscripcion: Enum_EstadoInscripcion
        fecha_ingreso: Date
        fecha_egreso: Date
    }
    type Avance {
        identificador: ID
        identificador_proyecto: identificador_proyecto
        fecha_avance: Date
        descripcion_avance: String
        observaciones_avance: [String]
        avance_creado_por: Usuario
    }
    type Query{
        usuarios: [Usuario]
        usuario(identificacion: Int): Usuario
        proyectos:[Proyecto]
        getProject(nombre:String):Proyecto
        Inscripciones: [Inscripcion]
        Avances: [Avance]
        filtrarAvance(idProyecto: String!): [Avance]
    }
    input UserInput{
        nombre: String
        identificacion:Int
        clave: String
        perfil: String
    }
    input ProjectInput{
        objetivosGenerales: String
        presupuesto: Int
        fechaTerminacion: Date
        lider: String
        nombre:String
    }
    type Mutation{
        createUser(user:UserInput):String
        createProject(project:ProjectInput):String
        activeUser(identificacion:Int):String
        deleteUser(ident:Int):String
        deleteProject(nombreProyecto:String):String
        insertUserToProject(identificacion:Int,nombreProyecto:String):String
        autenticar(usuario:String, clave:String):String
        crearInscripcion(estado_inscripcion:Enum_EstadoInscripcion, identificador_proyecto:String, identificador_estudiante:String):Inscripcion
        aprobarInscripcion(id:String):Inscripcion
        crearAvance(fecha_avance:Date, descripcion_avance:String, observaciones_avance:String, identificador_proyecto:String, avance_creado_por:String): Avance
    }
`
module.exports = typeDefs